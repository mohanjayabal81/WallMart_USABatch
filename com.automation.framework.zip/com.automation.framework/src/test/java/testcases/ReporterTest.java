package testcases;

import static org.testng.Assert.assertTrue;

import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

public class ReporterTest 
{
	ExtentReports extent;
	ExtentSparkReporter spark;
	
	@BeforeTest
	public void SetUp()
	{
		extent = new ExtentReports();
		spark = new ExtentSparkReporter("Reports/Spark.html");
		extent.attachReporter(spark);
	}
	
	@Test
	public void testcase1()
	{
		ExtentTest test = extent.createTest("User Verify the Application URL...");
		test.log(Status.PASS, "Testcase1 Passed");
		test.assignAuthor("Mohan").assignDevice("Windows").assignDevice("Chrome");
	}
	
	@Test
	public void testcase2()
	{
		ExtentTest test = extent.createTest("User Verify the WelCome Message...");
		try
		{
			assertTrue(false);
		}
		catch(AssertionError e)
		{
			test.log(Status.FAIL, "Testcase2 Failed.."+e.getMessage());
			test.assignAuthor("Mohan").assignDevice("Mac").assignDevice("Safari");
			System.out.println("Testcase2 Failed Block Executed..");
		}
		
	}
	
	@Test
	public void testcase3()
	{
		ExtentTest test = extent.createTest("User Verify the Title of WebPage...");
		test.log(Status.PASS, "Testcase3 Passed");
		test.assignAuthor("Mohan").assignDevice("Ubuntu").assignDevice("SunSolaris");
	}
	
	@Test
	public void testcase4()
	{
		ExtentTest test = extent.createTest("User Verify the Enter the Store URL...");
		test.log(Status.PASS, "Testcase4 Passed");
		test.assignAuthor("Mohan").assignDevice("Linux").assignDevice("FirFox");
	}
	
	@Test
	public void testcase5()
	{
		
		ExtentTest test = extent.createTest("User Verify the CopyRight Msg...");
		test.log(Status.PASS, "Testcase5 Passed");
		test.assignAuthor("Mohan").assignDevice("Windows").assignDevice("Chrome");
	}
	
	@AfterTest
	public void afterTest()
	{
		extent.flush();
	}

}
