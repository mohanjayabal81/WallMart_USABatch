package testcases;

import java.io.IOException;
import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

import browserImplementation.BrowserConfig;
import objectRepository.ObjectRepositoryReader;
import pages.LandingPage;
import pages.LoginPage;
import pages.LoginPageExcelImplementation;

public class VerifyLoginExcel 
{
	
	BrowserConfig broconf;
	WebDriver driver;
	ObjectRepositoryReader or;
	LandingPage lp;
	LoginPageExcelImplementation lep;
	
	ExtentReports extent;
	ExtentSparkReporter spark;
	
	@BeforeTest
	public void SetUp()
	{
		extent = new ExtentReports();
		spark = new ExtentSparkReporter("Reports/DDT_ExcelReport.html");
		extent.attachReporter(spark);
	}
	
	
	@BeforeMethod()
	public void setUp() throws IOException
	{
		 broconf = new BrowserConfig();
		 or = new ObjectRepositoryReader();		 
	}
	
	@Test 
	public void test_LoginToSite() throws IOException
	{
		 ExtentTest test = extent.createTest("DataDriven Testing Using Excel...");
		 test.log(Status.PASS, "LoginToSite Testcase Passed");
		 test.assignAuthor("Mohan").assignDevice("Windows").assignDevice("Chrome");
		 driver = broconf.Launch_Chrome();
		 driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(2));
		 driver.get(or.get_BaseURL());
		 lp = new LandingPage(driver);
		 lp.click_EntertheStore();
		 lep = new LoginPageExcelImplementation(driver);
		 lep.LoginToSite();// Calling the LoginPage Method		  
	}
	
	@AfterMethod
	public void tearDown()
	{
		driver.quit();
	}
	
	@AfterTest
	public void afterTest()
	{
		extent.flush();
	}
	
	
	 

}
