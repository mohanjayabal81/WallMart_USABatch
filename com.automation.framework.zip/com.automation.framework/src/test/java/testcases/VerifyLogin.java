package testcases;

import java.io.IOException;
import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import browserImplementation.BrowserConfig;
import objectRepository.ObjectRepositoryReader;
import pages.LandingPage;
import pages.LoginPage;

public class VerifyLogin 
{
	
	BrowserConfig broconf;
	WebDriver driver;
	ObjectRepositoryReader or;
	LandingPage lp;
	LoginPage lop;
	
	@BeforeMethod()
	public void setUp() throws IOException
	{
		 broconf = new BrowserConfig();
		 or = new ObjectRepositoryReader();
		 
	}
	
	@Test(dataProvider = "dp")
	public void test_LoginToSite(String username, String password)
	{
		 driver = broconf.Launch_Chrome();
		 driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(2));
		 driver.get(or.get_BaseURL());
		 lp = new LandingPage(driver);
		 lp.click_EntertheStore();
		 lop = new LoginPage(driver);
		 lop.LoginToSite(username,password); // Calling the LoginPage Method
		 driver.quit();
	}
	
	@DataProvider
	  public Object[][] dp() {
	    return new Object[][] {
	      new Object[] { "mohan", "mohan" },
	      new Object[] {"mohan1", "mohan1"  },
	      new Object[] {"mohan2", "mohan2"  },
	      new Object[] {"mohan3", "mohan3"  },
	    };
	  }

}
