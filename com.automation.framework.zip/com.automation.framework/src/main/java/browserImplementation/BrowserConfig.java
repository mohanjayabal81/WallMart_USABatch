package browserImplementation;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class BrowserConfig 
{
 
	public WebDriver Launch_Chrome()
	{
		WebDriver driver = new ChromeDriver(); // Chrome Browser Implementation 
		  return driver;
	}
	public WebDriver Launch_Edge()
	{
		WebDriver driver = new EdgeDriver(); //Edge Browser Implementation
		  return driver;
	}
	public WebDriver Launch_Firefox()
	{
		WebDriver driver = new FirefoxDriver(); // Firefox Browser Implementation 
		  return driver;
	}

}
