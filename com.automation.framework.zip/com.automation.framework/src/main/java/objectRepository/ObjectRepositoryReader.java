package objectRepository;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

public class ObjectRepositoryReader
{
	Properties objpro;
	
	public ObjectRepositoryReader() throws IOException
	{
		String path ="D:\\Clients\\KH\\Walmart\\SeleniumTestAutomation\\com.automation.framework\\ObjectRepository\\object.properties";
	    FileReader reader = new FileReader(path);
	    
	    objpro = new Properties();
	    objpro.load(reader);
	    
	}
	
	public String get_BaseURL()
	{
		return objpro.getProperty("BaseURL");
	}
	public String Click_EnterStore()
	{
		return objpro.getProperty("landingpage.enterstore.link");
	}
	
	

}
