package pages;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Reporter;
import org.testng.annotations.Test;

import excelImplementation.ExcelReader;

public class LoginPageExcelImplementation
{
	WebDriver driver;
	ExcelReader er;
	public LoginPageExcelImplementation(WebDriver driver)
	{
		this.driver = driver;
		
	}
	

	public void LoginToSite() throws IOException
	{
		String path = "D:\\Clients\\KH\\Walmart\\SeleniumTestAutomation\\com.automation.framework\\DataSet\\TestDataSet.xlsx";
		er = new ExcelReader(path);
		int rowcount = er.getRowCount(0);
		for(int i=0;i<rowcount;i++)
		{
		driver.findElement(By.linkText("Sign In")).click();
		driver.findElement(By.name("username")).sendKeys(er.getData(0, i, 0));
		System.out.println(er.getData(0, i, 0));
		Reporter.log(er.getData(0, i, 0));
		driver.findElement(By.name("password")).clear();
		driver.findElement(By.name("password")).sendKeys(er.getData(0, i, 1));
		System.out.println(er.getData(0, i, 1));
		Reporter.log(er.getData(0, i, 1));
		driver.findElement(By.name("signon")).click();
		driver.findElement(By.linkText("Sign Out")).click();
		}
		
	}

}
