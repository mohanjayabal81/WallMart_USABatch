package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.Reporter;

import objectRepository.ObjectRepositoryReader;

public class LandingPage 
{
	WebDriver driver;
	ObjectRepositoryReader or;
	By enterStore = By.linkText("Enter the Store");
	
	public LandingPage(WebDriver driver)
	{
		this.driver = driver;
	}	
	public void verify_CurrentURl()
	{
		String actualURL = driver.getCurrentUrl();
		String expectedURL = "https://petstore.octoperf.com/";
		try
		{
			Assert.assertEquals(actualURL, expectedURL);
			System.out.println("URL Matching TestCase Passed..");
			Reporter.log("URL Matching TestCase Passed..");
		}
		catch(AssertionError e)
		{
			System.out.println("URL Not Matching Testcase Failed.."+e.getMessage());
			Reporter.log("URL Not Matching Testcase Failed..");
		}		
	}
	
	public void click_EntertheStore()
	{
		 driver.findElement(enterStore).click();
	}
	
	public void verify_PageTitle()
	{
		String actualTitle = driver.getTitle();
		String expectedTitle = "JPetStore Demo";
		try
		{
			Assert.assertEquals(actualTitle, expectedTitle);
			System.out.println("Title Matching TestCase Passed..");
			Reporter.log("Title Matching TestCase Passed..");
		}
		catch(AssertionError e)
		{
			System.out.println("Title Not Matching Testcase Failed.."+e.getMessage());
			Reporter.log("Title Not Matching Testcase Failed..");
		}		
		
	}
	
	public void verify_WelcomeMsg()
	{
		String actualMsg = driver.findElement(By.xpath("//*[@id='Content']/h2")).getText();
		String exMsg = "Welcome to JPetStore 6";
		try
		{
			Assert.assertEquals(actualMsg, exMsg);
			System.out.println("Welcome Message Matching TestCase Passed..");
			Reporter.log("Welcome Message TestCase Passed..");
		}
		catch(AssertionError e)
		{
			System.out.println("Welcome Message Not Matching Testcase Failed.."+e.getMessage());
			Reporter.log("Welcome Message Not Matching Testcase Failed..");
		}		
	}
	
	public void Verify_CopyRightMsg()
	{
		String actualMsg = driver.findElement(By.xpath("//*[@id=\"Content\"]/p[2]/sub")).getText();
		String exMsg = "Copyright www.mybatis.org";
		try
		{
			Assert.assertEquals(actualMsg, exMsg);
			System.out.println("CopyRight  Message Matching TestCase Passed..");
			Reporter.log("CopyRight  Message TestCase Passed..");
		}
		catch(AssertionError e)
		{
			System.out.println("CopyRight  Message Not Matching Testcase Failed.."+e.getMessage());
			Reporter.log("CopyRight  Message Not Matching Testcase Failed..");
		}		
	}

}
